
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jaeyow',
  applicationName: 'f1-apollo-graphql',
  appUid: 'rDVYc9lnG6jpBGGrwK',
  orgUid: 'Fh0N5sNHbT0hV5SMFt',
  deploymentUid: 'dc886be5-8239-4a6e-8776-db64fe1024eb',
  serviceName: 'f1-graphql-apollo',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'f1-graphql-apollo-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}